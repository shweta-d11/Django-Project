from django.shortcuts import render,redirect
from AdminApp.models import Category, PaymentMaster,Product,UserInfo
from UserApp.models import MyCart,OrderMaster
from datetime import datetime
from django.contrib import messages

# Create your views here.
def homepage(request):
    #fetch all records from category table
    cats = Category.objects.all()
    mobiles = Product.objects.all()
    return render(request,"homepage.html",{"cats":cats,"mobiles":mobiles})

def login(request):
    if(request.method=="GET"):
        return render(request,"login.html",{})
    else:
        uname = request.POST["uname"]
        password = request.POST["password"]
        try:
            user = UserInfo.objects.get(uname=uname,password=password)
            #messages.success(request,'Login Successful')
            #return redirect(login)
        except:
            #messages.success(request,'Invalid Login')
            return redirect(login)
        else:
            request.session["uname"]=uname
            return redirect(homepage)
            

def signout(request):
    request.session.clear()
    return redirect(homepage)


def signup(request):
    if(request.method=="GET"):
        return render(request,"signup.html",{})
    else:
        uname = request.POST["uname"]
        password = request.POST["password"]
        email = request.POST["email"]
        user = UserInfo(uname,password,email)
        user.save()
        return redirect(homepage)

def ShowMobiles(request,id):
    #get method returns single object
    id = Category.objects.get(id=id)
    #filter method returns multiple objects
    mobiles = Product.objects.filter(cat = id)
    cats = Category.objects.all()
    return render(request,"homepage.html",{"cats":cats,"mobiles":mobiles})

def ViewDetails(request,id):
    mobile = Product.objects.get(id=id)
    return render(request,"ViewDetails.html",{"mobile":mobile})

def addToCart(request):
    if(request.method=="POST"):
        if("uname" in request.session):
            #add to cart
            #user and product
            mobileid = request.POST["mobileid"]
            user = request.session["uname"]
            qty = request.POST["qty"]
            mobile = Product.objects.get(id=mobileid)
            user = UserInfo.objects.get(uname=user)
            cart = MyCart()
            #check for duplicate entry
            try:
                cart=MyCart.objects.get(mobile=mobile,user=user)
            except:
                cart.user = user
                cart.mobile = mobile
                cart.qty = qty
                cart.save()
            else:
                pass
            return redirect(homepage)
        else:
            return redirect(login)

def ShowAllCartItems(request):
    uname = request.session["uname"]
    user = UserInfo.objects.get(uname=uname)
    if(request.method == "GET"):
        cartitems = MyCart.objects.filter(user=user)
        total = 0
        for item in cartitems:
            total+= item.qty*item.mobile.price
        request.session["total"] = total
        return render(request,"ShowAllCartItems.html",{"items":cartitems})
    else:
        id = request.POST["mobileid"]
        mobile = Product.objects.get(id=id)
        item = MyCart.objects.get(user=user,mobile=mobile)
        qty = request.POST["qty"]
        item.qty = qty
        item.save()
        return redirect(ShowAllCartItems)

def removeItem(request):
    uname = request.session["uname"]
    user = UserInfo.objects.get(uname=uname)
    id = request.POST["mobileid"]
    mobile = Product.objects.get(id=id)
    item = MyCart.objects.get(user=user,mobile=mobile)
    item.delete()
    return redirect(ShowAllCartItems)

def MakePayment(request):
    if(request.method=="GET"):
        return render(request,"MakePayment.html",{})
    else:
        cardno = request.POST["cardno"]
        cvv = request.POST["cvv"]
        expiry = request.POST["expiry"]
        try:
            buyer = PaymentMaster.objects.get(cardno=cardno,cvv=cvv,expiry=expiry)
        except:
            return redirect(MakePayment)
        else:
            #its a match
            owner = PaymentMaster.objects.get(cardno='111',cvv='111',expiry='12/2025')
            owner.balance +=request.session["total"]
            buyer.balance -=request.session["total"]
            owner.save()
            buyer.save()
            
            #delete from cart
            uname = request.session["uname"]
            user = UserInfo.objects.get(uname=uname)
            order = OrderMaster()
            order.user = user
            order.amount = request.session["total"]
            #order.dateOfOrder = datetime.now
            #fetch all cart items from user
            details = ""
            items = MyCart.objects.filter(user=user)
            for item in items:
                details+=item.mobile.pname+" "
                item.delete()
            order.details = details
            order.save()
            return redirect(homepage)
            

